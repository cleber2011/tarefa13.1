//01 - Pacote
package tarefa13_1;

//02 - Bibliotecas =

import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


//03 - Classes = objetos
public class compraExercicio131 {
    //3.1 - Atributos = Caracteristicas
    String url; // variavel para o site, que ser� utilizado para os testes
    WebDriver driver; // motor Selenium WebDriver

    //3.2 - M�todos ou Funcionalidades = O que vai fazer (m�todo executa mas sem retorno)
    @Before
    public void pesquisar() {
        // declarando site para acesso aos testes
        url = "https://iterasys.com.br";

        // liga��o do WebDriver (selenium) e o chrome (browser)
        System.setProperty("webdriver.chrome.driver", "drivers/chrome/87/chromedriver.exe");

        // Instanciar o objeto Selenium WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize(); // Maximiza a tela
        driver.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);


    }

    @After
    public void finalizar() {
        driver.quit(); // finalizar(destrui) o objeto Selenium WebDriver
    }

    @Test
    public void consultarMantis() throws InterruptedException {
        driver.get(url);
        driver.findElement(By.cssSelector("a.cc-btn.cc-dismiss")).click();
        driver.findElement(By.id("searchtext")).sendKeys("Mantis"); // Digita Testlink
        Thread.sleep(2000);
        //driver.findElement(By.id("searchtext")).sendKeys(Keys.chord("Testlink")); // Soletra Testlink
        driver.findElement(By.id("btn_form_search")).click(); // Clica na lupa de pesquisa
        //Thread.sleep(2000);
        driver.findElement(By.cssSelector("span.comprar")).click(); // Clica no bot�o MATRICULE-SE

        // Validar nome do curso
        String resultadoEsperado1 = "Mantis";
        String resultadoAtual1 = driver.findElement(By.cssSelector("span.item-title")).getText();
        assertEquals(resultadoAtual1, resultadoEsperado1);
        Thread.sleep(9000);

        // Validar o pre�o
        assertEquals("R$ 22,90", driver.findElement(By.cssSelector("span.new-price")).getText());
        Thread.sleep(9000);

        // Validar o Sub Total
        String resultadoEsperado2 = "SUBTOTAL R$ 22,90";
        String resultadoAtual2 = driver.findElement(By.cssSelector("div.subtotal")).getText();
        assertEquals(resultadoEsperado2, resultadoAtual2);
        Thread.sleep(9000);

        // Validar parcelamento
        assertTrue(driver.findElement(By.cssSelector("div.ou-parcele")).getText().contains("ou em 3 x de R$ 7,63 * no cart�o"));
    }



}






